export interface Category {
  id: number;
  name: string;

}

export const categories = [
  {
    id: 1,
    name: "Books",
  },
  {
    id: 2,
    name: "Phones",
  },
  {
    id: 3,
    name: "Routers",
  }
  ,
  {
    id: 4,
    name: "Printers",
  }
]