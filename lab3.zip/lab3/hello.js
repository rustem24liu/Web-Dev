console.log("Hello, World!")

function myfunc(){
    window.alert("Are you sure?")
    document.getElementById("demo").innerHTML = "Pragraph changed!"
    document.getElementById("header1").innerHTML = "Hello, again again"
    
}