function ucFirst(str){
    return str.toUpperCase();
}

console.log(ucFirst("german") == "GERMAN")