let now = new Date(0);

now = new Date(24 * 3600 * 1000)

console.log(now)


let date = new Date("2017-01-26")
console.log(date)


date = new Date().getTimezoneOffset()
// console.log(date.getHours())
// console.log(date.getDate())
// console.log(date.getDay())
// console.log(date.getFullYear())
