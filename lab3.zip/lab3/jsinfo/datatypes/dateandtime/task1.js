// let date = new Date("2012-02-20T03:12");
let date
date = new Date(2012, 2, 20, 3, 12)
console.log(date)