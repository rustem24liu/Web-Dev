let message;

message = "Hello, ";

alert(message)