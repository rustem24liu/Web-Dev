function myfunc(){
    alert("Are you sure to watch my website?")
}

myfunc()
