res = 0
n = int(input())
for i in range(n):
    a = int(input())
    if a == 0:
        res+=1

print(res)