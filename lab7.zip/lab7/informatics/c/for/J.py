res = 0
for i in range(100):
    a = int(input())
    res += a

print(res)