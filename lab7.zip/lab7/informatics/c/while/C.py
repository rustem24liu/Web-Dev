n=int(input())
p=1
while p<=n:
    print(p,end=' ')
    p=p*2