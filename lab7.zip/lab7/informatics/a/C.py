n, k = int(int(input())), int(input())

res = k//n
print(res)