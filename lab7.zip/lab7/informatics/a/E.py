v, t = int(input()), int(input())

circle = 109

S = v*t

print(S%circle)