number = int(input())

print(f"The next number for the number {number} is {number+1}.")
print(f"The previous number for the number {number} is {number-1}.")