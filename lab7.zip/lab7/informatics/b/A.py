a, b = int(input()), int(input())

print(max(a, b))
