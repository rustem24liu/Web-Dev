a = int(input())

if a > 0:
    res = 1
elif a < 0:
    res = -1
else:
    res = 0

print(res)