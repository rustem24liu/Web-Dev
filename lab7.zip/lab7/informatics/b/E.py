a, b = int(input()), int(input())

if a > b:
    print(1)
elif a < b:
    print(2)
else:
    print(0)