
N = int(input())

arr = list(map(int, input().split()))

for i in range(0, N, 2):
    print(arr[i], end=' ')
