def missing_char(str, n):
    part1 = str[:n]
    part2 = str[n + 1:]

    return part1 + part2